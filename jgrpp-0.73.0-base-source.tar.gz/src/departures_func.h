/* $Id: departures_func.h $ */

/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file departures_func.h Functions related to departures. */

#ifndef DEPARTURES_FUNC_H
#define DEPARTURES_FUNC_H

#include "station_base.h"
#include "departures_type.h"

#include <vector>

DepartureList MakeDepartureList(DeparturesSourceMode source_mode, DepartureOrderDestinationDetector source, const std::span<const Vehicle *> vehicles, DepartureTypes types, DepartureCallingSettings calling_settings);

Ticks GetDeparturesMaxTicksAhead();

#endif /* DEPARTURES_FUNC_H */
