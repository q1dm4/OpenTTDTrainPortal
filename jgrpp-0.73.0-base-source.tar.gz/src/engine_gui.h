/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file engine_gui.h %Engine GUI functions, used by build_vehicle_gui and autoreplace_gui. */

#ifndef ENGINE_GUI_H
#define ENGINE_GUI_H

#include "engine_type.h"
#include "group_type.h"
#include "newgrf_badge_gui.h"
#include "sortlist_type.h"
#include "gfx_type.h"
#include "vehicle_type.h"
#include "engine_base.h"
#include "window_type.h"
#include "3rdparty/cpp-btree/btree_map.h"

struct BuildVehicleWindowBase;

struct GUIEngineListSortCache {
	const BuildVehicleWindowBase *parent = nullptr;
	CargoType current_cargo = INVALID_CARGO;
	mutable btree::btree_map<EngineID, uint> capacities;

	void UpdateCargoFilter(const BuildVehicleWindowBase *parent, CargoType cargo_filter_criteria);
	uint GetArticulatedCapacity(EngineID eng, bool dual_headed = false) const;
};

template <>
struct GUIListParamConfig<GUIEngineListSortCache>
{
	using SortParameterReference = GUIEngineListSortCache;
	static const bool constructor_init = false;
};

struct GUIEngineListItem {
	EngineID engine_id;       ///< Engine to display in build purchase list
	EngineID variant_id;      ///< Variant group of the engine.
	EngineDisplayFlags flags; ///< Flags for toggling/drawing (un)folded status and controlling indentation.
	uint8_t indent;           ///< Display indentation level.
	uint16_t level_mask;      ///< Mask of level continuations.

	GUIEngineListItem(EngineID engine_id, EngineID variant_id, EngineDisplayFlags flags, uint8_t indent) : engine_id(engine_id), variant_id(variant_id), flags(flags), indent(indent), level_mask(0) {}
};

typedef GUIList<GUIEngineListItem, GUIEngineListSortCache, CargoType> GUIEngineList;

typedef bool EngList_SortTypeFunction(const GUIEngineListItem&, const GUIEngineListItem&, const GUIEngineListSortCache &); ///< argument type for #EngList_Sort.
void EngList_Sort(GUIEngineList &el, EngList_SortTypeFunction compare);
void EngList_SortPartial(GUIEngineList &el, EngList_SortTypeFunction compare, size_t begin, size_t num_items);

StringID GetEngineCategoryName(EngineID engine);
std::string GetEngineInfoString(EngineID engine);

void DrawVehicleEngine(int left, int right, int preferred_x, int y, EngineID engine, PaletteID pal, EngineImageType image_type);
void DrawTrainEngine(int left, int right, int preferred_x, int y, EngineID engine, PaletteID pal, EngineImageType image_type);
void DrawRoadVehEngine(int left, int right, int preferred_x, int y, EngineID engine, PaletteID pal, EngineImageType image_type);
void DrawShipEngine(int left, int right, int preferred_x, int y, EngineID engine, PaletteID pal, EngineImageType image_type);
void DrawAircraftEngine(int left, int right, int preferred_x, int y, EngineID engine, PaletteID pal, EngineImageType image_type);

extern bool _engine_sort_direction;
extern VehicleTypeIndexArray<uint8_t> _engine_sort_last_criteria;
extern VehicleTypeIndexArray<bool> _engine_sort_last_order;
extern VehicleTypeIndexArray<bool> _engine_sort_show_hidden_engines;


/**
 * Get the engine sorter functions for a \c VehicleType
 * @param vehicle_type the vehicle type
 * @return list of sorter functions.
 */
inline std::span<EngList_SortTypeFunction * const> GetEngineSortFunctions(VehicleType vehicle_type)
{
	extern const std::array<std::initializer_list<EngList_SortTypeFunction * const>, 4> _engine_sort_functions;
	assert(vehicle_type < VehicleType::CompanyEnd);
	return _engine_sort_functions[to_underlying(vehicle_type)];
}

/**
 * Get the engine sorter names for a \c VehicleType
 * @param vehicle_type the vehicle type
 * @return list of sorter names.
 */
inline std::span<StringID const> GetEngineSortNames(VehicleType vehicle_type)
{
	extern const std::array<std::initializer_list<const StringID>, 4> _engine_sort_listing;
	assert(vehicle_type < VehicleType::CompanyEnd);
	return _engine_sort_listing[to_underlying(vehicle_type)];
}

/* Functions in build_vehicle_gui.cpp */
uint GetEngineListHeight(VehicleType type);
void DisplayVehicleSortDropDown(Window *w, VehicleType vehicle_type, int selected, WidgetID button);
void DrawEngineList(VehicleType type, const Rect &r, const GUIEngineList &eng_list, const class Scrollbar &sb, EngineID selected_id, bool show_count, GroupID selected_group, const GUIBadgeClasses &badge_classes, StringID sort_criteria);
void GUIEngineListAddChildren(GUIEngineList &dst, const GUIEngineList &src, EngineID parent = EngineID::Invalid(), uint8_t indent = 0);

#endif /* ENGINE_GUI_H */
