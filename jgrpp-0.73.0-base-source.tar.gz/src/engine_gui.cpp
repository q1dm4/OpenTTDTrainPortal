/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file engine_gui.cpp GUI to show engine related information. */

#include "stdafx.h"
#include "dropdown_func.h"
#include "window_gui.h"
#include "engine_base.h"
#include "engine_cmd.h"
#include "command_func.h"
#include "core/string_builder.hpp"
#include "strings_func.h"
#include "engine_gui.h"
#include "articulated_vehicles.h"
#include "vehicle_func.h"
#include "company_func.h"
#include "date_func.h"
#include "rail.h"
#include "road.h"
#include "settings_type.h"
#include "train.h"
#include "roadveh.h"
#include "ship.h"
#include "aircraft.h"
#include "zoom_func.h"

#include "widgets/engine_widget.h"

#include "table/strings.h"

#include "safeguards.h"

/**
 * Return the category of an engine.
 * @param engine Engine to examine.
 * @return String describing the category ("road veh", "train". "airplane", or "ship") of the engine.
 */
StringID GetEngineCategoryName(EngineID engine)
{
	const Engine *e = Engine::Get(engine);
	switch (e->type) {
		default: NOT_REACHED();
		case VehicleType::Road:
			return GetRoadTypeInfo(e->VehInfo<RoadVehicleInfo>().roadtype)->strings.new_engine;
		case VehicleType::Aircraft:
			return STR_ENGINE_PREVIEW_AIRCRAFT;
		case VehicleType::Ship:
			return STR_ENGINE_PREVIEW_SHIP;
		case VehicleType::Train:
			assert(e->VehInfo<RailVehicleInfo>().railtypes.Any());
			return GetRailTypeInfo(e->VehInfo<RailVehicleInfo>().railtypes.GetNthSetBit(0).value())->strings.new_loco;
	}
}

static constexpr std::initializer_list<NWidgetPart> _nested_engine_preview_widgets = {
	NWidget(NWID_HORIZONTAL),
		NWidget(WWT_CLOSEBOX, Colours::LightBlue),
		NWidget(WWT_CAPTION, Colours::LightBlue, WID_EP_CAPTION), SetToolTip(STR_TOOLTIP_WINDOW_TITLE_DRAG_THIS),
	EndContainer(),
	NWidget(WWT_PANEL, Colours::LightBlue),
		NWidget(NWID_VERTICAL), SetPIP(0, WidgetDimensions::unscaled.vsep_wide, 0), SetPadding(WidgetDimensions::unscaled.modalpopup),
			NWidget(WWT_EMPTY, Colours::Invalid, WID_EP_QUESTION), SetMinimalSize(300, 0), SetFill(1, 0),
			NWidget(NWID_HORIZONTAL, NWidContainerFlag::EqualSize), SetPIP(85, WidgetDimensions::unscaled.hsep_wide, 85),
				NWidget(WWT_PUSHTXTBTN, Colours::LightBlue, WID_EP_NO), SetStringTip(STR_QUIT_NO), SetFill(1, 0),
				NWidget(WWT_PUSHTXTBTN, Colours::LightBlue, WID_EP_YES), SetStringTip(STR_QUIT_YES), SetFill(1, 0),
			EndContainer(),
		EndContainer(),
	EndContainer(),
	NWidget(NWID_HORIZONTAL),
		NWidget(WWT_PUSHTXTBTN, Colours::LightBlue, WID_EP_PREV), SetStringTip(STR_ENGINE_PREVIEW_PREVIOUS, STR_ENGINE_PREVIEW_PREVIOUS_TOOLTIP), SetFill(1, 0),
		NWidget(WWT_DROPDOWN, Colours::LightBlue, WID_EP_LIST), SetToolTip(STR_ENGINE_PREVIEW_ENGINE_LIST_TOOLTIP), SetFill(1, 0),
		NWidget(WWT_PUSHTXTBTN, Colours::LightBlue, WID_EP_NEXT), SetStringTip(STR_ENGINE_PREVIEW_NEXT, STR_ENGINE_PREVIEW_NEXT_TOOLTIP), SetFill(1, 0),
	EndContainer(),
};

struct EnginePreviewWindow : Window {
	int vehicle_space = 0; ///< The space to show the vehicle image
	size_t selected_index = 0; ///< The currently displayed index in the list of engines.
	std::vector<EngineID> engines; ///< List of engine IDs to display preview news for.

	/**
	 * Construct a new Engine Preview window.
	 * @param desc Window description.
	 * @param engine Initial engine to display.
	 */
	EnginePreviewWindow(WindowDesc &desc, EngineID engine) : Window(desc)
	{
		this->engines.push_back(engine);

		this->InitNested();
		this->SetWidgetsDisabledState(true, WID_EP_PREV, WID_EP_LIST, WID_EP_NEXT);

		/* There is no way to recover the window; so disallow closure via DEL; unless SHIFT+DEL */
		this->flags.Set(WindowFlag::Sticky);
	}

	std::string GetWidgetString(WidgetID widget, StringID stringid) const override
	{
		if (widget == WID_EP_CAPTION) {
			if (this->engines.size() <= 1) return GetString(STR_ENGINE_PREVIEW_CAPTION);
			return GetString(STR_ENGINE_PREVIEW_CAPTION_COUNT, this->selected_index + 1, this->engines.size());
		}

		if (widget == WID_EP_LIST) {
			return this->selected_index < this->engines.size() ? GetString(STR_ENGINE_PREVIEW_ENGINE_LIST, this->selected_index + 1, this->engines[this->selected_index]) : GetString(STR_INVALID_VEHICLE);
		}

		return this->Window::GetWidgetString(widget, stringid);
	}

	void UpdateWidgetSize(WidgetID widget, Dimension &size, [[maybe_unused]] const Dimension &padding, [[maybe_unused]] Dimension &fill, [[maybe_unused]] Dimension &resize) override
	{
		switch (widget) {
			case WID_EP_QUESTION: {
				/* Get size of engine sprite, on loan from depot_gui.cpp */
				EngineImageType image_type = EIT_PREVIEW;

				/* First determine required the horizontal size. */
				this->vehicle_space = ScaleSpriteTrad(40);
				for (const EngineID &engine : this->engines) {
					uint x, y;
					int x_offs, y_offs;

					const Engine *e = Engine::Get(engine);
					switch (e->type) {
						default: NOT_REACHED();
						case VehicleType::Train: GetTrainSpriteSize(engine, x, y, x_offs, y_offs, image_type); break;
						case VehicleType::Road: GetRoadVehSpriteSize(engine, x, y, x_offs, y_offs, image_type); break;
						case VehicleType::Ship: GetShipSpriteSize(engine, x, y, x_offs, y_offs, image_type); break;
						case VehicleType::Aircraft: GetAircraftSpriteSize(engine, x, y, x_offs, y_offs, image_type); break;
					}

					this->vehicle_space = std::max<int>(this->vehicle_space, y - y_offs);
					size.width = std::max(size.width, x + std::abs(x_offs));
				}

				/* Then account for the description of each vehicle. */
				int height = 0;
				for (const EngineID &engine : this->engines) {
					int title_height = GetStringHeight(GetString(STR_ENGINE_PREVIEW_MESSAGE, GetEngineCategoryName(engine)), size.width);
					int body_height = GetStringHeight(GetEngineInfoString(engine), size.width);
					height = std::max(height, title_height + WidgetDimensions::scaled.vsep_wide + GetCharacterHeight(FontSize::Normal) + this->vehicle_space + body_height);
				}

				size.height = height;
				break;
			}

			case WID_EP_LIST: {
				size.width = 0;
				int index = 0;
				for (const EngineID &engine : this->engines) {
					size.width = std::max(size.width, GetStringBoundingBox(GetString(STR_ENGINE_PREVIEW_ENGINE_LIST, index + 1, PackEngineNameDParam(engine, EngineNameContext::PreviewNews))).width);
					++index;
				}
				size.width += padding.width;
				break;
			}
		}
	}

	void DrawWidget(const Rect &r, WidgetID widget) const override
	{
		if (widget != WID_EP_QUESTION) return;

		if (this->selected_index >= this->engines.size()) return;

		EngineID engine = this->engines[selected_index];
		int y = DrawStringMultiLine(r, GetString(STR_ENGINE_PREVIEW_MESSAGE, GetEngineCategoryName(engine)), TextColour::FromString, SA_HOR_CENTER | SA_TOP) + WidgetDimensions::scaled.vsep_wide;

		DrawString(r.left, r.right, y, GetString(STR_ENGINE_NAME, PackEngineNameDParam(engine, EngineNameContext::PreviewNews)), TextColour::Black, SA_HOR_CENTER);
		y += GetCharacterHeight(FontSize::Normal);

		DrawVehicleEngine(r.left, r.right, this->width >> 1, y + this->vehicle_space / 2, engine, GetEnginePalette(engine, _local_company), EIT_PREVIEW);

		y += this->vehicle_space;
		DrawStringMultiLine(r.left, r.right, y, r.bottom, GetEngineInfoString(engine), TextColour::Black, SA_CENTER);
	}

	void OnClick([[maybe_unused]] Point pt, WidgetID widget, [[maybe_unused]] int click_count) override
	{
		switch (widget) {
			case WID_EP_YES:
				if (this->selected_index < this->engines.size()) {
					Command<Commands::WantEnginePreview>::Post(this->engines[this->selected_index]);
				}
				[[fallthrough]];

			case WID_EP_NO:
				if (!_shift_pressed) {
					this->engines.erase(this->engines.begin() + this->selected_index);
					this->InvalidateData();
				}
				break;

			case WID_EP_PREV:
				this->selected_index = (this->selected_index + this->engines.size() - 1) % this->engines.size();
				this->SetDirty();
				break;

			case WID_EP_NEXT:
				this->selected_index = (this->selected_index + 1) % this->engines.size();
				this->SetDirty();
				break;

			case WID_EP_LIST:
				ShowDropDownList(this, this->BuildDropdownList(), static_cast<int>(this->selected_index), widget);
				break;
		}
	}

	void OnDropdownSelect(WidgetID widget, int index, int) override
	{
		if (widget != WID_EP_LIST) return;
		this->selected_index = index % this->engines.size();
		this->SetDirty();
	}

	/**
	 * Build the dropdown list of new engines.
	 * @return The dropdown list.
	 */
	DropDownList BuildDropdownList()
	{
		DropDownList list;

		int index = 0;
		for (const EngineID &engine : this->engines) {
			list.push_back(MakeDropDownListStringItem(GetString(STR_ENGINE_PREVIEW_ENGINE_LIST, index + 1, PackEngineNameDParam(engine, EngineNameContext::PreviewNews)), index, false, false));
			++index;
		}

		return list;
	}

	void OnInvalidateData([[maybe_unused]] int data = 0, [[maybe_unused]] bool gui_scope = true) override
	{
		if (!gui_scope) return;

		/* Remove engines that are no longer eligible for preview. */
		for (auto it = this->engines.begin(); it != this->engines.end(); /* nothing */) {
			if (Engine::Get(*it)->preview_company != _local_company) {
				it = this->engines.erase(it);
			} else {
				++it;
			}
		}

		/* If no engines are remaining, close the window. */
		if (this->engines.empty()) this->Close();

		/* Ensure selection is valid. */
		if (this->selected_index >= this->engines.size()) this->selected_index = this->engines.size() - 1;

		this->SetWidgetsDisabledState(this->engines.size() <= 1, WID_EP_PREV, WID_EP_LIST, WID_EP_NEXT);
	}

	/**
	 * Adds another engine to the engine preview window.
	 * @param engine Engine ID to add.
	 */
	void AddEngineToPreview(EngineID engine)
	{
		if (std::ranges::find_if(this->engines, [engine](const EngineID &e) { return e == engine; }) != std::end(this->engines)) return;

		this->engines.push_back(engine);

		this->InvalidateData();
		this->ReInit();
	}
};

/** Window definition for the engine preview window. */
static WindowDesc _engine_preview_desc(__FILE__, __LINE__,
	WindowPosition::Center, nullptr, 0, 0,
	WindowClass::EnginePreview, WindowClass::None,
	WindowDefaultFlag::Construction,
	_nested_engine_preview_widgets
);


void ShowEnginePreviewWindow(EngineID engine)
{
	EnginePreviewWindow *w = dynamic_cast<EnginePreviewWindow *>(FindWindowByClass(WindowClass::EnginePreview));
	if (w == nullptr) {
		new EnginePreviewWindow(_engine_preview_desc, engine);
	} else {
		w->AddEngineToPreview(engine);
	}
}

/**
 * Get the capacity of an engine with articulated parts.
 * @param engine The engine to get the capacity of.
 * @param attempt_refit Attempt to get capacity when refitting to this cargo.
 * @return The capacity.
 */
uint GetTotalCapacityOfArticulatedParts(EngineID engine, CargoType attempt_refit)
{
	CargoArray cap = GetCapacityOfArticulatedParts(engine, attempt_refit);
	return cap.GetSum<uint>();
}

static StringID GetEngineInfoCapacityStringParameter(EngineID engine)
{
	CargoArray cap = GetCapacityOfArticulatedParts(engine);
	if (cap.GetSum<uint>() == 0) {
		/* no cargo at all */
		auto tmp_params = MakeParameters(INVALID_CARGO, 0);
		_temp_special_strings[1] = GetStringWithArgs(STR_JUST_CARGO, tmp_params);
	} else {
		format_buffer buffer;
		for (uint i = 0; i < NUM_CARGO; i++) {
			if (cap[i] == 0) continue;

			if (!buffer.empty()) {
				buffer.append(GetListSeparator());
			}

			AppendStringInPlace(buffer, STR_JUST_CARGO, i, cap[i]);
		}
		_temp_special_strings[1] = buffer.to_string();
	}

	return SPECSTR_TEMP_START + 1;
}

static StringID ProcessEngineCapacityString(StringID str)
{
	_temp_special_strings[0] = str_replace_wchar(GetStringPtr(str), SCC_CARGO_LONG, SCC_STRING);
	return SPECSTR_TEMP_START;
}

static StringID GetRunningCostString()
{
	if (DayLengthFactor() > 1 && !_settings_client.gui.show_running_costs_calendar_year) {
		return STR_ENGINE_PREVIEW_RUNCOST_ORIG_YEAR;
	} else if (EconTime::UsingWallclockUnits()) {
		return STR_ENGINE_PREVIEW_RUNCOST_PERIOD;
	} else {
		return STR_ENGINE_PREVIEW_RUNCOST_YEAR;
	}
}

static std::string GetTrainEngineInfoString(const Engine &e)
{
	format_buffer res;

	AppendStringInPlace(res, STR_ENGINE_PREVIEW_COST_WEIGHT, e.GetCost(), e.GetDisplayWeight());
	res.push_back('\n');

	const RailVehicleInfo &rvi = e.VehInfo<RailVehicleInfo>();
	if (!HasAtMostOneBit(rvi.railtypes)) {
		format_buffer_sized<128> railtypes;
		std::string_view list_separator = GetListSeparator();

		for (const auto &rt : _sorted_railtypes) {
			if (!rvi.railtypes.Test(rt)) continue;

			if (!railtypes.empty()) railtypes.append(list_separator);
			AppendStringInPlace(railtypes, GetRailTypeInfo(rt)->strings.name);
		}
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_RAILTYPES, railtypes);
		res.push_back('\n');
	}

	bool is_maglev = true;
	for (RailType rt : rvi.railtypes) {
		is_maglev &= GetRailTypeInfo(rt)->acceleration_type == VehicleAccelerationModel::Maglev;
	}

	if (_settings_game.vehicle.train_acceleration_model != AM_ORIGINAL && !is_maglev) {
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_SPEED_POWER_MAX_TE, PackVelocity(e.GetDisplayMaxSpeed(), e.type), e.GetPower(), e.GetDisplayMaxTractiveEffort());
		res.push_back('\n');
	} else {
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_SPEED_POWER, PackVelocity(e.GetDisplayMaxSpeed(), e.type), e.GetPower());
		res.push_back('\n');
	}

	AppendStringInPlace(res, GetRunningCostString(), e.GetDisplayRunningCost());
	res.push_back('\n');

	AppendStringInPlace(res, ProcessEngineCapacityString(STR_ENGINE_PREVIEW_CAPACITY), GetEngineInfoCapacityStringParameter(e.index));

	return res.to_string();
}

static std::string GetAircraftEngineInfoString(const Engine &e)
{
	format_buffer res;

	AppendStringInPlace(res, STR_ENGINE_PREVIEW_COST_MAX_SPEED, e.GetCost(), PackVelocity(e.GetDisplayMaxSpeed(), e.type));
	res.push_back('\n');

	if (uint16_t range = e.GetRange(); range > 0) {
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_TYPE_RANGE, e.GetAircraftTypeText(), range);
		res.push_back('\n');
	} else {
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_TYPE, e.GetAircraftTypeText());
		res.push_back('\n');
	}

	AppendStringInPlace(res, GetRunningCostString(), e.GetDisplayRunningCost());
	res.push_back('\n');

	CargoType cargo = e.GetDefaultCargoType();
	uint16_t mail_capacity;
	uint capacity = e.GetDisplayDefaultCapacity(&mail_capacity);
	if (mail_capacity > 0) {
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_CAPACITY_2, cargo, capacity, GetCargoTypeByLabel(CT_MAIL), mail_capacity);
	} else {
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_CAPACITY, cargo, capacity);
	}

	return res.to_string();
}

static std::string GetRoadVehEngineInfoString(const Engine &e)
{
	format_buffer res;

	if (_settings_game.vehicle.roadveh_acceleration_model == AM_ORIGINAL) {
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_COST_MAX_SPEED, e.GetCost(), PackVelocity(e.GetDisplayMaxSpeed(), e.type));
		res.push_back('\n');
	} else {
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_COST_WEIGHT, e.GetCost(), e.GetDisplayWeight());
		res.push_back('\n');
		AppendStringInPlace(res, STR_ENGINE_PREVIEW_SPEED_POWER_MAX_TE, PackVelocity(e.GetDisplayMaxSpeed(), e.type), e.GetPower(), e.GetDisplayMaxTractiveEffort());
		res.push_back('\n');
	}

	AppendStringInPlace(res, GetRunningCostString(), e.GetDisplayRunningCost());
	res.push_back('\n');

	AppendStringInPlace(res, ProcessEngineCapacityString(STR_ENGINE_PREVIEW_CAPACITY), GetEngineInfoCapacityStringParameter(e.index));

	return res.to_string();
}

static std::string GetShipEngineInfoString(const Engine &e)
{
	format_buffer res;

	AppendStringInPlace(res, STR_ENGINE_PREVIEW_COST_MAX_SPEED, e.GetCost(), PackVelocity(e.GetDisplayMaxSpeed(), e.type));
	res.push_back('\n');

	AppendStringInPlace(res, GetRunningCostString(), e.GetDisplayRunningCost());
	res.push_back('\n');

	AppendStringInPlace(res, ProcessEngineCapacityString(STR_ENGINE_PREVIEW_CAPACITY), GetEngineInfoCapacityStringParameter(e.index));

	return res.to_string();
}


/**
 * Get a multi-line string with some technical data, describing the engine.
 * @param engine Engine to describe.
 * @return String describing the engine.
 * @post \c DParam array is set up for printing the string.
 */
std::string GetEngineInfoString(EngineID engine)
{
	const Engine &e = *Engine::Get(engine);

	switch (e.type) {
		case VehicleType::Train:
			return GetTrainEngineInfoString(e);

		case VehicleType::Road:
			return GetRoadVehEngineInfoString(e);

		case VehicleType::Ship:
			return GetShipEngineInfoString(e);

		case VehicleType::Aircraft:
			return GetAircraftEngineInfoString(e);

		default: NOT_REACHED();
	}
}

/**
 * Draw an engine.
 * @param left   Minimum horizontal position to use for drawing the engine
 * @param right  Maximum horizontal position to use for drawing the engine
 * @param preferred_x Horizontal position to use for drawing the engine.
 * @param y      Vertical position to use for drawing the engine.
 * @param engine Engine to draw.
 * @param pal    Palette to use for drawing.
 * @param image_type Context where the image is being drawn.
 */
void DrawVehicleEngine(int left, int right, int preferred_x, int y, EngineID engine, PaletteID pal, EngineImageType image_type)
{
	const Engine *e = Engine::Get(engine);

	switch (e->type) {
		case VehicleType::Train:
			DrawTrainEngine(left, right, preferred_x, y, engine, pal, image_type);
			break;

		case VehicleType::Road:
			DrawRoadVehEngine(left, right, preferred_x, y, engine, pal, image_type);
			break;

		case VehicleType::Ship:
			DrawShipEngine(left, right, preferred_x, y, engine, pal, image_type);
			break;

		case VehicleType::Aircraft:
			DrawAircraftEngine(left, right, preferred_x, y, engine, pal, image_type);
			break;

		default: NOT_REACHED();
	}
}

/**
 * Sort all items using quick sort and given 'CompareItems' function
 * @param el list to be sorted
 * @param compare function for evaluation of the quicksort
 */
void EngList_Sort(GUIEngineList &el, EngList_SortTypeFunction compare)
{
	if (el.size() < 2) return;
	std::sort(el.begin(), el.end(), [&](const GUIEngineListItem &a, const GUIEngineListItem &b) {
		return compare(a, b, el.SortParameterData());
	});
}

/**
 * Sort selected range of items (on indices @ <begin, begin+num_items-1>)
 * @param el list to be sorted
 * @param compare function for evaluation of the quicksort
 * @param begin start of sorting
 * @param num_items count of items to be sorted
 */
void EngList_SortPartial(GUIEngineList &el, EngList_SortTypeFunction compare, size_t begin, size_t num_items)
{
	if (num_items < 2) return;
	assert(begin < el.size());
	assert(begin + num_items <= el.size());
	std::sort(el.begin() + begin, el.begin() + begin + num_items, [&](const GUIEngineListItem &a, const GUIEngineListItem &b) {
		return compare(a, b, el.SortParameterData());
	});
}

