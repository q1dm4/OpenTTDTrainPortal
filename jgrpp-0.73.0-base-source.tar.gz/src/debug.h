/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file debug.h Functions related to debugging. */

#ifndef DEBUG_H
#define DEBUG_H

#include "core/format.hpp"
#include <array>
#include <string>

/* Debugging messages policy:
 * These should be the severities used for direct Debug() calls
 * maximum debugging level should be 10 if really deep, deep
 * debugging is needed.
 * (there is room for exceptions, but you have to have a good cause):
 * 0   - errors or severe warnings
 * 1   - other non-fatal, non-severe warnings
 * 2   - crude progress indicator of functionality
 * 3   - important debugging messages (function entry)
 * 4   - debugging messages (crude loop status, etc.)
 * 5   - detailed debugging information
 * 6.. - extremely detailed spamming
 */

enum class DebugLevelID : uint8_t {
	driver,
	grf,
	map,
	misc,
	net,
	sprite,
	oldloader,
	yapf,
	fontcache,
	script,
	sl,
	gamelog,
	desync,
	yapfdesync,
	console,
	linkgraph,
	sound,
	command,
#ifdef RANDOM_DEBUG
	random,
	statecsum,
#endif
	END,
};
static constexpr uint DebugLevelCount = static_cast<uint>(DebugLevelID::END);

extern std::array<int8_t, DebugLevelCount> _debug_levels;

inline int8_t GetDebugLevel(DebugLevelID id) {
	return _debug_levels[static_cast<uint>(id)];
}

const char *GetDebugLevelName(DebugLevelID id);

template <typename... T>
void DebugIntl(DebugLevelID dbg, int8_t level, fmt::format_string<T...> msg, T&&... args)
{
	extern void DebugIntlVFmt(DebugLevelID dbg, int8_t level, fmt::string_view msg, fmt::format_args args);
	DebugIntlVFmt(dbg, level, msg, make_preprocessed_format_args(args...));
}

/**
 * Output a line of debugging information.
 * @param name The category of debug information.
 * @param level The maximum debug level this message should be shown at. When the debug level for this category is set lower, then the message will not be shown.
 * @param format_string The formatting string of the message.
 */
#define Debug(name, level, format_string, ...) do { if ((level) == 0 || GetDebugLevel(DebugLevelID::name) >= (level)) DebugIntl(DebugLevelID::name, level, FMT_STRING(format_string) __VA_OPT__(,) __VA_ARGS__); } while (false)

extern const char *_savegame_DBGL_data;
extern std::string _loadgame_DBGL_data;
extern bool _save_DBGC_data;
extern std::string _loadgame_DBGC_data;

void debug_print(DebugLevelID dbg, int8_t level, std::string_view msg);

void DumpDebugFacilityNames(struct format_target &output);
using SetDebugStringErrorFunc = void(std::string_view);
void SetDebugString(std::string_view s, SetDebugStringErrorFunc error_func);
std::string GetDebugString();

/* Shorter form for passing filename and linenumber */
#define FILE_LINE __FILE__, __LINE__

void ShowInfoI(std::string_view str);

template <typename... T>
void ShowInfo(fmt::format_string<T...> msg, T&&... args)
{
	extern void ShowInfoVFmt(fmt::string_view msg, fmt::format_args args);
	ShowInfoVFmt(msg, make_preprocessed_format_args(args...));
}

struct log_prefix {
	std::string_view GetLogPrefix(bool force = false);

private:
	char buffer[24];
};

void ClearDesyncMsgLog();
void LogDesyncMsg(std::string msg);
void DumpDesyncMsgLog(struct format_target &buffer);

void DebugSendRemoteMessages();
void DebugReconsiderSendRemoteMessages();

template <typename... T>
[[noreturn]] void AssertMsgError(int line, const char *file, const char *expr, fmt::format_string<T...> msg, T&&... args)
{
	[[noreturn]] extern void AssertMsgErrorVFmt(int line, const char *file, const char *expr, fmt::string_view msg, fmt::format_args args);
	AssertMsgErrorVFmt(line, file, expr, msg, make_preprocessed_format_args(args...));
}
template <typename... T>
[[noreturn]] void AssertMsgTileError(int line, const char *file, const char *expr, uint32_t tile, fmt::format_string<T...> msg, T&&... args)
{
	[[noreturn]] extern void AssertMsgTileErrorVFmt(int line, const char *file, const char *expr, uint32_t tile, fmt::string_view msg, fmt::format_args args);
	AssertMsgTileErrorVFmt(line, file, expr, tile, msg, make_preprocessed_format_args(args...));
}

#if !defined(NDEBUG) || defined(WITH_ASSERT)
#	define assert_msg(expression, ...) do { if (unlikely(!(expression))) AssertMsgError(__LINE__, __FILE__, #expression, __VA_ARGS__); } while (false)
#	define assert_msg_tile(expression, tile, ...) do { if (unlikely(!(expression))) AssertMsgTileError(__LINE__, __FILE__, #expression, debug_tile_index_type_erasure(tile), __VA_ARGS__); } while (false)
#else
#	define assert_msg(expression, ...)
#	define assert_msg_tile(expression, tile, ...)
#endif

#endif /* DEBUG_H */
