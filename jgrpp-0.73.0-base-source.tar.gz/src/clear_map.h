/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file clear_map.h Map accessors for 'clear' tiles. */

#ifndef CLEAR_MAP_H
#define CLEAR_MAP_H

#include "bridge_map.h"
#include "industry_type.h"

static constexpr size_t CLEAR_GROUND_BITS = 3; ///< How many bits in map array are dedicated for clear ground type.

/**
 * Ground types. Valid densities in comments after the enum.
 */
enum class ClearGround : uint8_t {
	Grass = 0, ///< Plain grass with dirt transition (0-3)
	Rough = 1, ///< Rough mounds (3)
	Rocks = 2, ///< Rocks with snow transition (0-3)
	Fields = 3, ///< Farm fields (3)
	Snow = 4, ///< Snow: Not stored in map
	Desert = 5, ///< Desert with transition (1,3)

	End, ///< End marker.
	MaxSize = 1U << CLEAR_GROUND_BITS, ///< The maximum possible number of clear ground types to be stored in map.
};

static_assert(ClearGround::End <= ClearGround::MaxSize);

/**
 * Test if a tile is covered with snow.
 * @param t the tile to check
 * @pre IsTileType(t, TileType::Clear)
 * @return whether the tile is covered with snow.
 */
inline bool IsSnowTile(TileIndex t)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t);
	return HasBit(_m[t].m3, 4);
}

/**
 * Get the type of clear tile.
 * @param t the tile to get the clear ground type of
 * @pre IsTileType(t, TileType::Clear)
 * @return the ground type
 */
inline ClearGround GetClearGround(TileIndex t)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t);
	return static_cast<ClearGround>(GB(_m[t].m5, 2, CLEAR_GROUND_BITS));
}

/**
 * Set the type of clear tile.
 * @param t  the tile to set the clear ground type of
 * @param ct the ground type
 * @pre IsTileType(t, TileType::Clear)
 * @return \c true when the ground is of the given ground type.
 */
inline bool IsClearGround(TileIndex t, ClearGround ct)
{
	return GetClearGround(t) == ct;
}


/**
 * Get the density of a non-field clear tile.
 * @param t the tile to get the density of
 * @pre IsTileType(t, TileType::Clear)
 * @return the density
 */
inline uint GetClearDensity(TileIndex t)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t);
	return GB(_m[t].m5, 0, 2);
}

/**
 * Increment the density of a non-field clear tile.
 * @param t the tile to increment the density of
 * @param d the amount to increment the density with
 * @pre IsTileType(t, TileType::Clear)
 */
inline void AddClearDensity(TileIndex t, int d)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t); // XXX incomplete
	_m[t].m5 += d;
}

/**
 * Set the density of a non-field clear tile.
 * @param t the tile to set the density of
 * @param d the new density
 * @pre IsTileType(t, TileType::Clear)
 */
inline void SetClearDensity(TileIndex t, uint d)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t);
	SB(_m[t].m5, 0, 2, d);
}


/**
 * Get the counter used to advance to the next clear density/field type.
 * @param t the tile to get the counter of
 * @pre IsTileType(t, TileType::Clear)
 * @return the value of the counter
 */
inline uint GetClearCounter(TileIndex t)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t);
	return GB(_m[t].m5, 5, 3);
}

/**
 * Increments the counter used to advance to the next clear density/field type.
 * @param t the tile to increment the counter of
 * @param c the amount to increment the counter with
 * @pre IsTileType(t, TileType::Clear)
 */
inline void AddClearCounter(TileIndex t, int c)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t); // XXX incomplete
	_m[t].m5 += c << 5;
}

/**
 * Sets the counter used to advance to the next clear density/field type.
 * @param t the tile to set the counter of
 * @param c the amount to set the counter to
 * @pre IsTileType(t, TileType::Clear)
 */
inline void SetClearCounter(TileIndex t, uint c)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t); // XXX incomplete
	SB(_m[t].m5, 5, 3, c);
}


/**
 * Sets ground type and density in one go, also sets the counter to 0
 * @param t       the tile to set the ground type and density for
 * @param type    the new ground type of the tile
 * @param density the density of the ground tile
 * @pre IsTileType(t, TileType::Clear)
 */
inline void SetClearGroundDensity(TileIndex t, ClearGround type, uint density)
{
	dbg_assert_tile(IsTileType(t, TileType::Clear), t); // XXX incomplete
	_m[t].m5 = 0 << 5 | to_underlying(type) << 2 | density;
}


/**
 * Get the field type (production stage) of the field
 * @param t the field to get the type of
 * @pre GetClearGround(t) == ClearGround::Fields
 * @return the field type
 */
inline uint GetFieldType(TileIndex t)
{
	dbg_assert_tile(GetClearGround(t) == ClearGround::Fields, t);
	return GB(_m[t].m3, 0, 4);
}

/**
 * Set the field type (production stage) of the field
 * @param t the field to get the type of
 * @param f the field type
 * @pre GetClearGround(t) == ClearGround::Fields
 */
inline void SetFieldType(TileIndex t, uint f)
{
	dbg_assert_tile(GetClearGround(t) == ClearGround::Fields, t); // XXX incomplete
	SB(_m[t].m3, 0, 4, f);
}

/**
 * Get the industry (farm) that made the field
 * @param t the field to get creating industry of
 * @pre GetClearGround(t) == ClearGround::Fields
 * @return the industry that made the field
 */
inline IndustryID GetIndustryIndexOfField(TileIndex t)
{
	dbg_assert_tile(GetClearGround(t) == ClearGround::Fields, t);
	return(IndustryID) _m[t].m2;
}

/**
 * Set the industry (farm) that made the field
 * @param t the field to get creating industry of
 * @param i the industry that made the field
 * @pre GetClearGround(t) == ClearGround::Fields
 */
inline void SetIndustryIndexOfField(TileIndex t, IndustryID i)
{
	dbg_assert_tile(GetClearGround(t) == ClearGround::Fields, t);
	_m[t].m2 = i.base();
}


/**
 * Is there a fence at the given border?
 * @param t the tile to check for fences
 * @param side the border to check
 * @pre IsClearGround(t, ClearGround::Fields)
 * @return 0 if there is no fence, otherwise the fence type
 */
inline uint GetFence(TileIndex t, DiagDirection side)
{
	dbg_assert_tile(IsClearGround(t, ClearGround::Fields), t);
	switch (side) {
		default: NOT_REACHED();
		case DiagDirection::SE: return GB(_m[t].m4, 2, 3);
		case DiagDirection::SW: return GB(_m[t].m4, 5, 3);
		case DiagDirection::NE: return GB(_m[t].m3, 5, 3);
		case DiagDirection::NW: return GB(_me[t].m6, 2, 3);
	}
}

/**
 * Sets the type of fence (and whether there is one) for the given border.
 * @param t the tile to check for fences
 * @param side the border to check
 * @param h 0 if there is no fence, otherwise the fence type
 * @pre IsClearGround(t, ClearGround::Fields)
 */
inline void SetFence(TileIndex t, DiagDirection side, uint h)
{
	dbg_assert_tile(IsClearGround(t, ClearGround::Fields), t);
	switch (side) {
		default: NOT_REACHED();
		case DiagDirection::SE: SB(_m[t].m4, 2, 3, h); break;
		case DiagDirection::SW: SB(_m[t].m4, 5, 3, h); break;
		case DiagDirection::NE: SB(_m[t].m3, 5, 3, h); break;
		case DiagDirection::NW: SB(_me[t].m6, 2, 3, h); break;
	}
}


/**
 * Make a clear tile.
 * @param t       the tile to make a clear tile
 * @param g       the type of ground
 * @param density the density of the grass/snow/desert etc
 */
inline void MakeClear(TileIndex t, ClearGround g, uint density)
{
	SetTileType(t, TileType::Clear);
	_m[t].m1 = 0;
	SetTileOwner(t, OWNER_NONE);
	_m[t].m2 = 0;
	_m[t].m3 = 0;
	_m[t].m4 = 0 << 5 | 0 << 2;
	SetClearGroundDensity(t, g, density); // Sets m5
	_me[t].m6 = 0;
	_me[t].m7 = 0;
	_me[t].m8 = 0;
}


/**
 * Make a (farm) field tile.
 * @param t          the tile to make a farm field
 * @param field_type the 'growth' level of the field
 * @param industry   the industry this tile belongs to
 */
inline void MakeField(TileIndex t, uint field_type, IndustryID industry)
{
	SetTileType(t, TileType::Clear);
	_m[t].m1 = 0;
	SetTileOwner(t, OWNER_NONE);
	_m[t].m2 = industry.base();
	_m[t].m3 = field_type;
	_m[t].m4 = 0 << 5 | 0 << 2;
	SetClearGroundDensity(t, ClearGround::Fields, 3);
	_me[t].m6 = 0;
	_me[t].m7 = 0;
	_me[t].m8 = 0;
}

/**
 * Make a snow tile.
 * @param t the tile to make snowy
 * @param density The density of snowiness.
 * @pre !IsSnowTile(t)
 */
inline void MakeSnow(TileIndex t, uint density = 0)
{
	dbg_assert_tile(!IsSnowTile(t), t);
	SetBit(_m[t].m3, 4);
	if (GetClearGround(t) == ClearGround::Fields) {
		SetClearGroundDensity(t, ClearGround::Grass, density);
	} else {
		SetClearDensity(t, density);
	}
}

/**
 * Clear the snow from a tile and return it to its previous type.
 * @param t the tile to clear of snow
 * @pre IsSnowTile(t)
 */
inline void ClearSnow(TileIndex t)
{
	dbg_assert_tile(IsSnowTile(t), t);
	ClrBit(_m[t].m3, 4);
	SetClearDensity(t, 3);
}

#endif /* CLEAR_MAP_H */
